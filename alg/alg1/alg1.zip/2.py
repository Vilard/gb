print(5&6)
# 5 == 101
# 6 == 110
# true false false => 1 0 0 => 4
print(5|6)
# true true true => 1 1 1 => 7
print(5>>2)
# remove 2 bit left => 1
print(6>>2)
# remove 2 bit left => 1
print(5<<2)
# append 2 bit left 101 00 => 20
print(6<<2)
# append 2 bit left 110 00 => 24


